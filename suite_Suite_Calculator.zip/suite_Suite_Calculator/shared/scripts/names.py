# encoding: UTF-8

from objectmaphelper import *

app                              ="quickaddressbook"
o_QQuickView                     = {"type": "QQuickView", "unnamed": 1, "visible": True}
window_Rectangle                 = {"container": o_QQuickView, "id": "window", "type": "Rectangle", "unnamed": 1, "visible": True}
QuickBookWindow                  = {"name": "mainWindow", "type": "QQuickWindowQmlImpl", "visible": True}
AddressBookView                  = {"container": QuickBookWindow, "id": "addressBookView", "type": "AddressBookView", "unnamed": 1, "visible": True}
rowItem_addressBook              = {"container": AddressBookView, "id": "rowitem", "rowIndex": 0, "type": "FocusScope", "unnamed": 1, "visible": True}
FirstRowInAddressBook            = {"container": rowItem_addressBook, "objectName": "label", "type": "Text", "visible": True}
MainWindow_ToolBar               = {"container": QuickBookWindow, "type": "ToolBar", "unnamed": 1, "visible": True}
Remove_Button                    = {"container": MainWindow_ToolBar, "text": "&Remove", "type": "Button", "unnamed": 1, "visible": True}
Add_Button                       = {"container": MainWindow_ToolBar, "text": "&Add", "type": "Button", "unnamed": 1, "visible": True}
Edit_View                        = {"container": QuickBookWindow, "id": "editView", "type": "EditView", "unnamed": 1, "visible": True}
EditView_FirstName               = {"container": Edit_View, "id": "firstNameField", "type": "TextField", "unnamed": 1, "visible": True}
EditView_LastName                = {"container": Edit_View, "id": "lastNameField", "type": "TextField", "unnamed": 1, "visible": True}
EditView_PhoneNumber             = {"container": Edit_View, "id": "phoneNumberField", "type": "TextField", "unnamed": 1, "visible": True}
EditView_EmailAddress            = {"container": Edit_View, "id": "emailAddressField", "type": "TextField", "unnamed": 1, "visible": True}
Back_Buton                       = {"container": MainWindow_ToolBar, "text": "&Back", "type": "Button", "unnamed": 1, "visible": True}
rowitem_label_Text = {"container": rowItem_addressBook, "objectName": "label", "occurrence": 3, "type": "Text", "visible": True}
rowitem_label_Text_2 = {"container": rowItem_addressBook, "objectName": "label", "occurrence": 4, "type": "Text", "visible": True}
addressBookView_listView_ListView = {"container": AddressBookView, "id": "listView", "type": "ListView", "unnamed": 1, "visible": True}
address_Book_MainWindow = {"type": "MainWindow", "unnamed": 1, "visible": 1, "windowTitle": "Address Book"}
address_Book_File_QToolBar = {"type": "QToolBar", "unnamed": 1, "visible": 1, "window": address_Book_MainWindow, "windowTitle": "File"}
address_Book_File_QTableWidget = {"aboveWidget": address_Book_File_QToolBar, "type": "QTableWidget", "unnamed": 1, "visible": 1, "window": address_Book_MainWindow}
address_Book_New_QToolButton = {"text": "New", "type": "QToolButton", "unnamed": 1, "visible": 1, "window": address_Book_MainWindow}
address_Book_Unnamed_MainWindow = {"type": "MainWindow", "unnamed": 1, "visible": 1, "windowTitle": "Address Book - Unnamed"}
address_Book_Unnamed_New_QToolButton = {"text": "New", "type": "QToolButton", "unnamed": 1, "visible": 1, "window": address_Book_Unnamed_MainWindow}
address_Book_Unnamed_Add_QToolButton = {"text": "Add", "type": "QToolButton", "unnamed": 1, "visible": 1, "window": address_Book_Unnamed_MainWindow}
address_Book_Add_Dialog = {"type": "Dialog", "unnamed": 1, "visible": 1, "windowTitle": "Address Book - Add"}
address_Book_Add_Forename_QLabel = {"text": "Forename:", "type": "QLabel", "unnamed": 1, "visible": 1, "window": address_Book_Add_Dialog}
forename_LineEdit = {"buddy": address_Book_Add_Forename_QLabel, "type": "LineEdit", "unnamed": 1, "visible": 1}
shapes_MainWindow = {"type": "MainWindow", "unnamed": 1, "visible": 1, "windowTitle": "Shapes"}
shapes_QGraphicsView = {"type": "QGraphicsView", "unnamed": 1, "visible": 1, "window": shapes_MainWindow}
o_QGraphicsProxyWidget = {"acceptDrops": "yes", "container": shapes_QGraphicsView, "enabled": "yes", "focusable": "yes", "movable": "no", "selectable": "no", "type": "QGraphicsProxyWidget", "visible": "yes"}
add_Polygon_QPushButton = {"container": o_QGraphicsProxyWidget, "text": "Add Polygon", "type": "QPushButton", "unnamed": 1, "visible": 1}
o_QGraphicsPolygonItem = {"acceptDrops": "no", "container": shapes_QGraphicsView, "enabled": "yes", "fillColor": "#000000", "focusable": "no", "lineColor": "#000000", "movable": "yes", "selectable": "yes", "type": "QGraphicsPolygonItem", "visible": "yes"}
