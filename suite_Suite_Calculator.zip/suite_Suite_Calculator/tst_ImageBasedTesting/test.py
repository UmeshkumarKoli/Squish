# -*- coding: utf-8 -*-"

import names

def main():
    startApplication("quickaddressbook")

    mouseClick(waitForImage("row_first"))
    mouseClick(waitForImage("RemoveButton"))
    mouseClick(waitForImage("image"))
    mouseClick(waitForImage("RemoveButton"))

    test.log("Hello World")
