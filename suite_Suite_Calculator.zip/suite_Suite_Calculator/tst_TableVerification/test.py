# -*- coding: utf-8 -*-"

import names

def main():
    startApplication("addressbook")

    test.vp("VP1_Empty_Table") # if you enter a row this step will fail
    snooze(2)
