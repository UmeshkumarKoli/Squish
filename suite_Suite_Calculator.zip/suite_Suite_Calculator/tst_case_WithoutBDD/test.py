# -*- coding: utf-8 -*-

import names


def main():
    startApplication("quickaddressbook")

    mouseClick(waitForObject(names.FirstRowInAddressBook))
    mouseClick(waitForObject(names.Remove_Button))
    mouseClick(waitForObject(names.FirstRowInAddressBook))
    mouseClick(waitForObject(names.Remove_Button))
    # deleted all entries
    mouseClick(waitForObject(names.Add_Button))
    mouseClick(waitForObject(names.EditView_FirstName), 15, 15, Qt.LeftButton)
    type(waitForObject(names.EditView_FirstName), "Luis")
    mouseClick(waitForObject(names.EditView_LastName), 37, 12, Qt.ShiftModifier, Qt.LeftButton)
    type(waitForObject(names.EditView_LastName), "Pais")
    mouseClick(waitForObject(names.EditView_PhoneNumber), 32, 15, Qt.ShiftModifier, Qt.LeftButton)
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad+>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad3>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad5>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad1>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad->")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad9>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad6>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad5>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad4>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad7>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad0>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad0>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad3>")
    type(waitForObject(names.EditView_PhoneNumber), "<NumPad9>")
    mouseClick(waitForObject(names.EditView_EmailAddress), 34, 5, Qt.ShiftModifier, Qt.LeftButton)
    type(waitForObject(names.EditView_EmailAddress), "abc@gmail.com")
    mouseClick(waitForObject(names.Back_Buton), Qt.ShiftModifier, Qt.LeftButton)
    test.compare(waitForObjectExists(names.rowItem_addressBook).rowIndex, 0)
    

