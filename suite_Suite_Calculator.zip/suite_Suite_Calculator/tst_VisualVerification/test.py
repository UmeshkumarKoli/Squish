# -*- coding: utf-8 -*-"

import names

def main():
    startApplication("shapes")

    clickButton(waitForObject(names.add_Polygon_QPushButton))
    dragItemBy(waitForObject(names.o_QGraphicsPolygonItem), 39, 75, 96, 182, 1, Qt.LeftButton)
    test.vp("VP1")

